package android.arch.lifecycle;

public abstract class ViewModel {
    /* access modifiers changed from: protected */
    public void onCleared() {
    }
}
