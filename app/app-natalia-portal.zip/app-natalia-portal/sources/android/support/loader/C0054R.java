package android.support.loader;

import com.example.natalia.portalacademico.C0277R;

/* renamed from: android.support.loader.R */
public final class C0054R {

    /* renamed from: android.support.loader.R$attr */
    public static final class attr {
        public static final int alpha = 2130837543;
        public static final int font = 2130837626;
        public static final int fontProviderAuthority = 2130837628;
        public static final int fontProviderCerts = 2130837629;
        public static final int fontProviderFetchStrategy = 2130837630;
        public static final int fontProviderFetchTimeout = 2130837631;
        public static final int fontProviderPackage = 2130837632;
        public static final int fontProviderQuery = 2130837633;
        public static final int fontStyle = 2130837634;
        public static final int fontVariationSettings = 2130837635;
        public static final int fontWeight = 2130837636;
        public static final int ttcIndex = 2130837820;

        private attr() {
        }
    }

    /* renamed from: android.support.loader.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2130968639;
        public static final int notification_icon_bg_color = 2130968640;
        public static final int ripple_material_light = 2130968650;
        public static final int secondary_text_default_material_light = 2130968652;

        private color() {
        }
    }

    /* renamed from: android.support.loader.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131034187;
        public static final int compat_button_inset_vertical_material = 2131034188;
        public static final int compat_button_padding_horizontal_material = 2131034189;
        public static final int compat_button_padding_vertical_material = 2131034190;
        public static final int compat_control_corner_material = 2131034191;
        public static final int compat_notification_large_icon_max_height = 2131034192;
        public static final int compat_notification_large_icon_max_width = 2131034193;
        public static final int notification_action_icon_size = 2131034203;
        public static final int notification_action_text_size = 2131034204;
        public static final int notification_big_circle_margin = 2131034205;
        public static final int notification_content_margin_start = 2131034206;
        public static final int notification_large_icon_height = 2131034207;
        public static final int notification_large_icon_width = 2131034208;
        public static final int notification_main_column_padding_top = 2131034209;
        public static final int notification_media_narrow_margin = 2131034210;
        public static final int notification_right_icon_size = 2131034211;
        public static final int notification_right_side_padding_top = 2131034212;
        public static final int notification_small_icon_background_padding = 2131034213;
        public static final int notification_small_icon_size_as_large = 2131034214;
        public static final int notification_subtext_size = 2131034215;
        public static final int notification_top_pad = 2131034216;
        public static final int notification_top_pad_large_text = 2131034217;

        private dimen() {
        }
    }

    /* renamed from: android.support.loader.R$drawable */
    public static final class C0055drawable {
        public static final int notification_action_background = 2131099735;
        public static final int notification_bg = 2131099736;
        public static final int notification_bg_low = 2131099737;
        public static final int notification_bg_low_normal = 2131099738;
        public static final int notification_bg_low_pressed = 2131099739;
        public static final int notification_bg_normal = 2131099740;
        public static final int notification_bg_normal_pressed = 2131099741;
        public static final int notification_icon_background = 2131099742;
        public static final int notification_template_icon_bg = 2131099743;
        public static final int notification_template_icon_low_bg = 2131099744;
        public static final int notification_tile_bg = 2131099745;
        public static final int notify_panel_notification_icon_bg = 2131099746;

        private C0055drawable() {
        }
    }

    /* renamed from: android.support.loader.R$id */
    public static final class C0056id {
        public static final int action_container = 2131165197;
        public static final int action_divider = 2131165199;
        public static final int action_image = 2131165200;
        public static final int action_text = 2131165206;
        public static final int actions = 2131165207;
        public static final int async = 2131165213;
        public static final int blocking = 2131165216;
        public static final int chronometer = 2131165226;
        public static final int forever = 2131165248;
        public static final int icon = 2131165254;
        public static final int icon_group = 2131165255;
        public static final int info = 2131165258;
        public static final int italic = 2131165260;
        public static final int line1 = 2131165262;
        public static final int line3 = 2131165263;
        public static final int normal = 2131165271;
        public static final int notification_background = 2131165272;
        public static final int notification_main_column = 2131165273;
        public static final int notification_main_column_container = 2131165274;
        public static final int right_icon = 2131165283;
        public static final int right_side = 2131165284;
        public static final int tag_transition_group = 2131165316;
        public static final int tag_unhandled_key_event_manager = 2131165317;
        public static final int tag_unhandled_key_listeners = 2131165318;
        public static final int text = 2131165319;
        public static final int text2 = 2131165320;
        public static final int time = 2131165324;
        public static final int title = 2131165325;

        private C0056id() {
        }
    }

    /* renamed from: android.support.loader.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131230724;

        private integer() {
        }
    }

    /* renamed from: android.support.loader.R$layout */
    public static final class layout {
        public static final int notification_action = 2131296286;
        public static final int notification_action_tombstone = 2131296287;
        public static final int notification_template_custom_big = 2131296288;
        public static final int notification_template_icon_group = 2131296289;
        public static final int notification_template_part_chronometer = 2131296290;
        public static final int notification_template_part_time = 2131296291;

        private layout() {
        }
    }

    /* renamed from: android.support.loader.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131427369;

        private string() {
        }
    }

    /* renamed from: android.support.loader.R$style */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131493100;
        public static final int TextAppearance_Compat_Notification_Info = 2131493101;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131493102;
        public static final int TextAppearance_Compat_Notification_Time = 2131493103;
        public static final int TextAppearance_Compat_Notification_Title = 2131493104;
        public static final int Widget_Compat_NotificationActionContainer = 2131493208;
        public static final int Widget_Compat_NotificationActionText = 2131493209;

        private style() {
        }
    }

    /* renamed from: android.support.loader.R$styleable */
    public static final class styleable {
        public static final int[] ColorStateListItem = {16843173, 16843551, C0277R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = {C0277R.attr.fontProviderAuthority, C0277R.attr.fontProviderCerts, C0277R.attr.fontProviderFetchStrategy, C0277R.attr.fontProviderFetchTimeout, C0277R.attr.fontProviderPackage, C0277R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, C0277R.attr.font, C0277R.attr.fontStyle, C0277R.attr.fontVariationSettings, C0277R.attr.fontWeight, C0277R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        private styleable() {
        }
    }

    private C0054R() {
    }
}
