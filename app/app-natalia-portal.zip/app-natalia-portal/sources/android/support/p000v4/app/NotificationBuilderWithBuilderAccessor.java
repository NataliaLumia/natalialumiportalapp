package android.support.p000v4.app;

import android.app.Notification.Builder;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;

@RestrictTo({Scope.LIBRARY_GROUP})
/* renamed from: android.support.v4.app.NotificationBuilderWithBuilderAccessor */
public interface NotificationBuilderWithBuilderAccessor {
    Builder getBuilder();
}
