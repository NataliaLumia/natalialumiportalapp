package android.support.interpolator;

/* renamed from: android.support.interpolator.R */
public final class C0053R {
    private C0053R() {
    }
}
