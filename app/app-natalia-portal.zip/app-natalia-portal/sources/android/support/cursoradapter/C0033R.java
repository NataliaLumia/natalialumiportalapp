package android.support.cursoradapter;

/* renamed from: android.support.cursoradapter.R */
public final class C0033R {
    private C0033R() {
    }
}
