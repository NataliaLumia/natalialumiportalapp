package android.support.documentfile;

/* renamed from: android.support.documentfile.R */
public final class C0039R {
    private C0039R() {
    }
}
