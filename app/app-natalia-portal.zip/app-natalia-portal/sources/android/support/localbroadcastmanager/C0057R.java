package android.support.localbroadcastmanager;

/* renamed from: android.support.localbroadcastmanager.R */
public final class C0057R {
    private C0057R() {
    }
}
